### What steps will reproduce the problem?

### What is the expected result?

### What do you get instead?

### Additional info

| Q                 | A
| ----------------- | ---
| Yii2 version      |
| Yii2-rbac version |
| PHP version       | 
